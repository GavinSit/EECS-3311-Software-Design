# 3311-W20-Public

Public Material for [EECS3311-W20](https://wiki.eecs.yorku.ca/course_archive/2019-20/W/3311/start) students. 

* Lab0: Introduction to design using a minimal snooker table. Study together with [Eiffel-101](https://www.eecs.yorku.ca/~eiffel/pdf/Eiffel-101.pdf).
